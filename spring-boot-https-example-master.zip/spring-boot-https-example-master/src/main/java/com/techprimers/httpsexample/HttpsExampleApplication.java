package com.techprimers.httpsexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpsExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpsExampleApplication.class, args);
	}
}
